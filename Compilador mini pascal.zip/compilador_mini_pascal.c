/*INCLUINDO DEBUG PARA O CODIGO*/
//#define DEBUGLEX
#ifdef DEBUGLEX
#endif
//#define DEBUG
#ifdef DEBUG
#endif
/*palavras reservadas*/
#define _AND            101
#define _BOOLEAN        102
#define _BEGIN          103
#define _DO             104
#define _END            105
#define _ELSE           106
#define _FALSE          107
#define _INTEGER        108
#define _IF             109
#define _NOT            110
#define _OR             111
#define _PROCEDURE      112
#define _PROGRAM        113
#define _THEN           114
#define _TRUE           115
#define _VAR            116
#define _WRITE          117
#define _WHILE          118
/*operadores*/
#define _IGUAL          201
#define _OPMULT         202
#define _OPADI          203
#define _OPSUB          204
#define _MAIOR          205
#define _MENOR          206
#define _MAIORIGUAL     207
#define _MENORIGUAL     208
#define _ATRIBUICAO     209
#define _DIFERENTE      210
#define _DIV            211
/*digitos*/
#define _NUMBER         300
/*letras*/
#define _LETTER         400
/*delimitadores*/
#define _PNT            501
#define _VRGL           502
#define _PNTVRGL        503
#define _DSPNT          504
#define _ABREP          505
#define _FECHAP         506

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>


/*Metodo leitor - Automato responsavel pela identificacao de palavras reservadas da linguagem mini pascal
Lista de lexemas reservadas:            |  Lista de operadores:   |
and        begin       boolean    div    |  +	-	* 	) 	;	(  |
do         else        end.       false  |    :=  :  >=	 >	<=     |
if         integer     not        program|    <>  <   ,   :=       |
procedure  true        then       or     |  Lista de numerais:     |
var        write       while             | 0-1-2-3-4-5-6-7-8-9     |
*/
int leitor(char str[],int *p) {
    int i = *p;
	int erro = 0;

	goto Q0;

	Q0:
	    i++;
	    if(str[i] == ' ')
		    return -1;
		if(str[i] == '\n')
		    return 1;
	    if ((str[i] == '0')||(str[i] == '1')||(str[i] == '2')||(str[i] == '3')||(str[i] == '4')||(str[i] == '5')||(str[i] == '6')||(str[i] == '7')||(str[i] == '8')||(str[i] == '9')){
	        goto Q90;
	    } else {
	        if(str[i] == 'a'){
		       	goto Q42;
	        } else {
				if (str[i] == 'b'){
	                goto Q59;
	            } else {
	                if (str[i] == 'd'){
	                    goto Q72;
	                } else {
	                   	if (str[i] == 'e'){
	                        goto Q1;
	                    } else {
	                        if (str[i] == 'f'){
	                            goto Q45;
	                        } else {
	                            if (str[i] == 'i'){
	                                goto Q28;
	                            } else {
	                                if (str[i] == 'n'){
	                                    goto Q39;
	                                } else {
	                                    if (str[i] == 'o'){
	                                        goto Q74;
	                                    } else {
	                                        if (str[i] == 'p'){
	                                            goto Q15;
	                                        } else {
	                                            if (str[i] == 't'){
	                                                goto Q8;
	                                            } else {
	                                                if (str[i] == 'v'){
	                                                    goto Q36;
	                                                } else {
	                                                    if (str[i] == 'w'){
	                                                        goto Q50;
	                                                    } else {
	                                                        if (str[i] == '<'){
	                                                            goto Q76;
	                                                        } else {
	                                                        	if (str[i] == '>'){
	                                                                goto Q79;
	                                                            } else {
	                                                             	if (str[i] == ':'){
	                                                                    goto Q81;
	                                                                } else {
																		if (str[i] == ','){
																		    goto Q83;
																		} else {
																			if (str[i] == '('){
																		        goto Q84;
																			} else {
																			    if (str[i] == ';'){
																			        goto Q85;
																			    } else {
																			        if (str[i] == ')'){
																			            goto Q86;
																			        } else {
																			            if (str[i] == '*'){
																			                goto Q87;
																			            } else {
																			                if (str[i] == '-'){
																			                    goto Q88;
																			                } else {
																			                    if (str[i] == '+'){
																			                        goto Q89;
																			                    } else {
																			                        if (str[i] == '.'){
																			                            goto Q92;
																			                        } else {
																			                            goto Q91;
																							 	   }
																							    }
																							 }
																						}
																					}
																				}
																		    }
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
		    	}
		    }
		}
	/*else*/ /*end.*/
	Q1:
	    i++;
	    if(str[i] == 'n'){
			goto Q5;
	    } else {
	        if(str[i] == 'l'){
		       goto Q2;
		    } else {
		        if ((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
		        } else {
		           return _LETTER;
		        }
    	   }
        }
	Q2:
	    i++;
	    if(str[i] == 's'){
			goto Q3;
		 } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q3:
	    i++;
	    if(str[i] == 'e'){
			goto Q4;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q4:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _ELSE;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q5:
	    i++;
	    if(str[i] == 'd'){
		   *p = i;
		   goto Q6;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q6:
	    i++;
	    if(str[i] == ' '){
          *p = i;
           return _END;
        } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*true*/ /*then*/
	Q8:
	    i++;
	    if(str[i] == 'r'){
			goto Q9;
	    } else {
	        if(str[i] == 'h'){
		       goto Q12;
	       } else {
			    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
		            return 0;
		        } else {
		        	return _LETTER;
		        }
	        }
        }
	Q9:
	    i++;
	    if(str[i] == 'u'){
			goto Q10;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q10:
	    i++;
	    if(str[i] == 'e'){
			goto Q11;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q11:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _TRUE;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q12:
	    i++;
	    if(str[i] == 'e'){
			goto Q13;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q13:
	    i++;
	    if(str[i] == 'n'){
			goto Q14;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q14:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _THEN;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*program*/ /*procedure*/
	Q15:
	    i++;
	    if(str[i] == 'r'){
			goto Q16;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q16:
	    i++;
	    if(str[i] == 'o'){
			goto Q17;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q17:
	    i++;
	    if(str[i] == 'g'){
			goto Q18;
	    } else {
	        if(str[i] == 'c'){
		       goto Q22;
	        } else {
			    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
		            return 0;
		        } else {
		        	return _LETTER;
		        }
	        }
    	}
	Q18:
	    i++;
	    if(str[i] == 'r'){
			goto Q19;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q19:
	    i++;
	    if(str[i] == 'a'){
			goto Q20;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q20:
	    i++;
	    if(str[i] == 'm'){
			goto Q21;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q21:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _PROGRAM;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q22:
	    i++;
	    if(str[i] == 'e'){
			goto Q23;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q23:
	    i++;
	    if(str[i] == 'd'){
			goto Q24;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q24:
	    i++;
	    if(str[i] == 'u'){
			goto Q25;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q25:
	    i++;
	    if(str[i] == 'r'){
			goto Q26;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q26:
	    i++;
	    if(str[i] == 'e'){
			goto Q27;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q27:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _PROCEDURE;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*if*/ /*integer*/
	Q28:
	    i++;
	    if(str[i] == 'n'){
			goto Q30;
	        } else {
	           if(str[i] == 'f'){
		          goto Q29;
	            } else {
		            if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	                  return 0;
	                } else {
	        	        return _LETTER;
	                }
                }
           }
	Q29:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _IF;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q30:
	    i++;
	    if(str[i] == 't'){
			goto Q31;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q31:
	    i++;
	    if(str[i] == 'e'){
			goto Q32;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q32:
	    i++;
	    if(str[i] == 'g'){
			goto Q33;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q33:
	    i++;
	    if(str[i] == 'e'){
			goto Q34;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
    Q34:
	    i++;
	    if(str[i] == 'r'){
			goto Q35;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q35:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _INTEGER;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*var*/
    Q36:
	    i++;
	    if(str[i] == 'a'){
			goto Q37;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q37:
	    i++;
	    if(str[i] == 'r'){
			goto Q38;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q38:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _VAR;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*not*/
	Q39:
	    i++;
	    if(str[i] == 'o'){
			goto Q40;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q40:
	    i++;
	    if(str[i] == 't'){
			goto Q41;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q41:
		i++;
	    if (str[i] == ' ') {
           *p = i;
	        return _NOT;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*and*/
	Q42:
	    i++;
	    if(str[i] == 'n'){
			goto Q43;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q43:
	    i++;
	    if(str[i] == 'd'){
			goto Q44;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q44:
		i++;
	    if (str[i] == ' ') {
           *p = i;
	        return _AND;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*false*/
	Q45:
	    i++;
	    if(str[i] == 'a'){
			goto Q46;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q46:
	    i++;
	    if(str[i] == 'l'){
			goto Q47;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q47:
	    i++;
	    if(str[i] == 's'){
			goto Q48;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q48:
	    i++;
	    if(str[i] == 'e'){
			goto Q49;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q49:
		i++;
	    if (str[i] == ' ') {
           *p = i;
	        return _FALSE;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*write*/ /*while*/
	Q50:
	    i++;
	    if(str[i] == 'r'){
			goto Q51;
	    } else {
	         if(str[i] == 'h'){
		    	goto Q55;
		        } else {
			    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
		            return 0;
		        } else {
		        	return _LETTER;
		        }
	        }
		}
	Q51:
	    i++;
	    if(str[i] == 'i'){
			goto Q52;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q52:
	    i++;
	    if(str[i] == 't'){
			goto Q53;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q53:
	    i++;
	    if(str[i] == 'e'){
			goto Q54;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q54:
		i++;
	    if (str[i] == ' ') {
           *p = i;
	        return _WRITE;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q55:
	    i++;
	    if(str[i] == 'i'){
			goto Q56;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q56:
	    i++;
	    if(str[i] == 'l'){
			goto Q57;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q57:
	    i++;
	    if(str[i] == 'e'){
			goto Q58;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q58:
		i++;
	    if (str[i] == ' ') {
           *p = i;
	        return _WHILE;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*begin*/ /*boolean*/
	Q59:
	    i++;
	    if(str[i] == 'e'){
			goto Q60;
		} else{
		    if (str[i] == 'o'){
		        goto Q64;
		    } else {
			    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
		            return 0;
		        } else {
		        	return _LETTER;
		        }
		    }
		}
	Q60:
	    i++;
	    if(str[i] == 'g'){
			goto Q61;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q61:
	    i++;
	    if(str[i] == 'i'){
			goto Q62;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q62:
	    i++;
	    if(str[i] == 'n'){
			goto Q63;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q63:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _BEGIN;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q64:
	    i++;
	    if(str[i] == 'o'){
			goto Q65;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q65:
	    i++;
	    if(str[i] == 'l'){
			goto Q66;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q66:
	    i++;
	    if(str[i] == 'e'){
			goto Q67;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q67:
	    i++;
	    if(str[i] == 'a'){
			goto Q68;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q68:
	    i++;
	    if(str[i] == 'n'){
			goto Q69;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q69:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _BOOLEAN;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*div*/ /*do*/
	Q70:
		i++;
	    if(str[i] == 'v'){
			goto Q71;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q71:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _DIV;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q72:
	    i++;
	    if(str[i] == 'o'){
			goto Q73;
	    } else {
	         if(str[i] == 'i'){
			    goto Q70;
	        } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	}
	Q73:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _DO;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	 /*or*/
	Q74:
	    i++;
	    if(str[i] == 'r'){
			goto Q73;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	Q75:
		i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _OR;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	            return 0;
	        } else {
	        	return _LETTER;
	        }
        }
	/*<*/
	Q76:
	    i++;
	    if(str[i] == '>'){
			goto Q77;
	    } else {
	        if(str[i] == '='){
		   	   goto Q78;
	        } else {
	            if(str[i] == ' '){
                   *p = i;
		   	        return _MENOR;
	            } else {
	    	        return 0;
	        }
    	}
   }
	/*<>*/
	Q77:
	    i++;
	    if(str[i] == ' '){
        *p = i;
			  return _DIFERENTE;
	    } else {
	    	return 0;
	    }
	/*<=*/
	Q78:
	    i++;
	    if(str[i] == ' '){
        *p = i;
			return _MENORIGUAL;
	    } else {
	    	return 0;
	    }
	/*>*/
	Q79:
	    i++;
	    if(str[i] == '='){
			goto Q80;
	    } else {
	        if(str[i] == ' '){
            *p = i;
		   	   return _MAIOR;
	       } else {
	    	   return 0;
	    }
	}
	/*>=*/
	Q80:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _MAIORIGUAL;
	    }  else {
	         return 0;
		}
	/*:*/
	Q81:
	    i++;
	    if(str[i] == '='){
			goto Q82;
	    } else {
	        if(str[i] == ' '){
            *p = i;
		   	   return _DSPNT;
	       } else {
	    	   return 0;
	    }
	}
	/*:=*/
	Q82:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _ATRIBUICAO;
	    }  else {
	    	 return 0;
		}
	/*,*/
	Q83:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _VRGL;
	    }  else {
	    	 return 0;
		}
	/*(*/
	Q84:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _ABREP;
	    }  else {
	    	 return 0;
		}
	/*;*/
	Q85:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _PNTVRGL;
	    }  else {
	    	 return 0;
		}
	/*)*/
	Q86:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _FECHAP;
	    }  else {
	    	 return 0;
		}
	/***/
	Q87:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _OPMULT;
	      }else {
	    	 return 0;
		}
	/*-*/
	Q88:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _OPSUB;
	      }else {
	    	 return 0;
		}
	/*+*/
	Q89:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _OPADI;
	      }else {
	    	 return 0;
		}
	/*0-1-2-3-4-5-6-7-8-9*/
	Q90:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _NUMBER;
	    } else {
	        if ((str[i] == '0')||(str[i] == '1')||(str[i] == '2')||(str[i] == '3')||(str[i] == '4')||(str[i] == '5')||(str[i] == '6')||(str[i] == '7')||(str[i] == '8')||(str[i] == '9')){
	            goto Q90;
	        } else {
	   	     	return 0;
	    	}
    	}
    	 /*.*/
	Q92:
	    i++;
	    if (str[i] == ' ') {
          *p = i;
	        return _PNT;
	      }else {
	    	 return 0;
		}
    /*demais caracteres lidos*/
	Q91:
	    i++;
	    if (str[i] == ' ') {
           *p = i;
	        return _LETTER;
	    } else {
		    if((str[i] == '.')||(str[i] == ':')||(str[i] == ';')||(str[i] == ',')||(str[i] == '<')||(str[i] == '>')||(str[i] == '=')||(str[i] == '-')||(str[i] == '+')||(str[i] == '*')||(str[i] == ')')||(str[i] == '(')){
	          return 0;
	        } else {
	          goto Q91;
	        }
        }
	return 1;
}

/*Buffer que ira armazenar os tokens lidos pelo analizador lexico*/
struct Node{
	int escopo;
    int num;
    int lcodigo;
    char categoria[20];
    char tipo[20];
    char lexema[100];
 struct Node *prox;
};

typedef struct Node node;

//--------variavel global, identificador de checagem de tipo--------
char verifica_tipo[80];
//--------fim identificador de checagem de tipo---------------------

int tam;

void inicia(node *BUFFER);
int vazia(node *BUFFER);
node *aloca(int elem, char* s, int lcod);
void insereBuffer(node *BUFFER, int elem, char* s, int lcod);
node *marcaProx(node *BUFFER);
void exibe(node *BUFFER);
void libera(node *BUFFER);

//inicia o buffer
void inicia(node *BUFFER){
	BUFFER->prox = NULL;
	tam=0;
}
//verifica se o buffer esta vazio
int vazia(node *BUFFER){
	if(BUFFER->prox == NULL)
		return 1;
	else
		return 0;
}
//aloca o token lido no analisador lexico
node *aloca(int elem, char* s, int lcod){
	node *novo=(node *) malloc(sizeof(node));
	if(!novo){
		printf("Sem memoria disponivel!\n");
		exit(1);
	}else{
       novo->num = elem;
	   strcpy (novo->lexema, s);
	   novo->lcodigo = lcod;
	   return novo;
	}
}

//exibe os elementos dentro do buffer
void debugPrintLex(node *BUFFER){
    int count=0;
    #ifdef DEBUGLEX
	if(vazia(BUFFER)){
	   printf("BUFFER vazia!\n\n");
    }
	node *tmp;
	tmp = BUFFER->prox;
	printf("TOKENS NO BUFFER:\n");
	printf("| TOKEN LIDO | IDENTIFICADOR |\n");
	while( tmp != NULL){
      printf("|    %d     | %s\t     |\n", tmp->num,tmp->lexema);
	  tmp = tmp->prox;
	  count++;
    }
    #endif
}

void debugPrintSintat(node *BUFFER, char *regra){
	node *tmp;
	tmp = BUFFER->prox;
	#ifdef DEBUG
	if(regra ==""){
       printf ("\tLexema: <%s>\n",tmp->lexema);
    }else{
       printf ("Regra: %s\n", regra);
    }
    #endif
}
//libera o buffer

void libera(node *BUFFER){
	if(!vazia(BUFFER)){
		node *proxNode,
		*atual;
		atual = BUFFER->prox;
		while(atual != NULL){
			proxNode = atual->prox;
			free(atual);
			atual = proxNode;
		}
	}
}

//escreve o elemento lido dentro do buffer
void insereBuffer(node *BUFFER, int elem, char* s, int lcod){
    node *novo=aloca(elem, s, lcod);
   	novo->prox = NULL;
	if(vazia(BUFFER))
		BUFFER->prox=novo;
	else{
		node *tmp = BUFFER->prox;
		while(tmp->prox != NULL)
			tmp = tmp->prox;
		tmp->prox = novo;
	}
	tam++;
}

//retira o elemento a partir do topo do buffer
node *marcaProx(node *BUFFER){
	if(BUFFER->prox == NULL){
		printf("Fim do Programa\n");
		return NULL;
	}else{
		node *tmp = BUFFER->prox;
		BUFFER->prox = tmp->prox;
		return tmp;
	}
}

node *head(node *BUFFER){
    if(BUFFER->prox == NULL){
       exit(0);
    }else{
        node *tmp = BUFFER->prox;
		return tmp;
    }
}

int lookahead(node *BUFFER){
    if(BUFFER->prox == NULL){
       exit(0);
    }else{
        node *tmp = BUFFER->prox;
		return tmp->num;
    }
}


void match(node *BUFFER, int token){
	if(lookahead(BUFFER) == token){
		marcaProx(BUFFER);
		}else{
			printf("ERRO SINTATICO\n");
			exit(1);
		}
}

/*TABELA DE SIMBOLOS*/

void iniciaTabelaSimbolo(node *PILHA);
void exibeTabelaSimbolo(node *PILHA);
void liberaTabelaSimbolo(node *PILHA);
node *retirarTabelaSimbolo(node *PILHA);

//inicia a Tabela de Simbolo
void iniciaTabelaSimbolo(node *PILHA)
{
 PILHA->prox = NULL;
 tam=0;
}
//verifica se a Tabela de Simbolo esta vazia
int vaziaTabelaSimbolo(node *PILHA){
    if(PILHA->prox == NULL)
       return 1;
    else
       return 0;
}
//aloca o identificador lido na Tabela de Simbolo
node *alocaTabelaSimbolo(char* elem, int escopo, char* tipo, char* categoria){
    node *novo=(node *) malloc(sizeof(node));
	if(!novo){
       printf("Sem memoria disponivel!\n");
  	   exit(1);
	}else{
	   novo->escopo = escopo;
	   strcpy (novo->tipo, tipo);
	   strcpy (novo->categoria, categoria);
	   strcpy (novo->lexema, elem);
	   return novo;
	}
}
//exibe os elementos dentro da Tabela de Simbolo
void exibeTabelaSimbolo(node *PILHA){
    int count=0;
	if(vazia(PILHA)){
	   printf("\nA Tabela de Simbolos esta vazia!\n\n");
    }else{
		node *tmp;
		tmp = PILHA->prox;
		printf("\n\tTABELA DE SIMBOLOS:\n");
		printf("IDENTIFICADOR |  POSICAO  |  ESCOPO     |   TIPO        |   CATEGORIA\n");
		while( tmp != NULL){
		  printf("%s\t      |\t%d\t  |\t%d\t|\t%s|\t%s\n", tmp->lexema,count, tmp->escopo, tmp->tipo, tmp->categoria);
		  tmp = tmp->prox;
		  count++;
	    }
    }
}
//libera a Tabela de Simbolo
void liberaTabelaSimbolo(node *PILHA){
    if(!vazia(PILHA)){
       node *proxNode,
       *atual;
        atual = PILHA->prox;
        while(atual != NULL){
            proxNode = atual->prox;
            free(atual);
            atual = proxNode;
        }
    }
}
//escreve o elemento lido dentro da Tabela de Simbolo
void adicionaTabelaSimbolo(node *PILHA, char* elem, int escopo,  char* tipo, char* categoria){
    node *novo=alocaTabelaSimbolo(elem, escopo, tipo, categoria);
    novo->prox = NULL;
    if(vazia(PILHA))
      PILHA->prox=novo;
    else{
      node *tmp = PILHA->prox;
      while(tmp->prox != NULL)
        tmp = tmp->prox;
    tmp->prox = novo;
	}
    tam++;
}


//retira o elemento a partir do topo da Tabela de Simbolo
node *retirarTabelaSimbolo(node *PILHA){
    if(PILHA->prox == NULL){
       exit(0);
    }else{
        node *ultimo = PILHA->prox,
        *penultimo = PILHA;
        while(ultimo->prox != NULL){
            penultimo = ultimo;
            ultimo = ultimo->prox;
       }
    penultimo->prox = NULL;
    tam--;
    return ultimo;
    }
}
//verifica o topo da Tabela de Simbolo
node *topoTabelaSimbolo(node *PILHA){
    if(PILHA->prox == NULL){
       exit(0);
    }else{
        node *ultimo = PILHA->prox;
        while(ultimo->prox != NULL){
            ultimo = ultimo->prox;
       }
    return ultimo;
    }
}

int buscarTabelaSimbolo(node *PILHA, char *elem){
	if(vazia(PILHA)){
	   printf("A Tabela de Simbolos esta vazia vazia!\n\n");
    }
	else {
    node *ultimo = PILHA->prox,
    *penultimo = PILHA;

    while(ultimo->prox != NULL){
      if (strcmp(ultimo->lexema, elem) == 0){
        strcpy (verifica_tipo, ultimo->tipo);
        return 1;
      }
      penultimo = ultimo;
      ultimo = ultimo->prox;
  }
}
  return 0;
}
/* REGRAS DO ANALISADOR SINTATICO DESCENDENTE*/
void TIPO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void ID(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria, int modo);
void NUMERO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void BOOL(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void VARIAVEL(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void FATOR(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void TERMO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void ExprSimples(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void ATRIB(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void COMDCOND1(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void COMDCOND2(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void CMDREP1(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void CMD(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void CPROC(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void RELACAO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void Expr(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void ListaID(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void SecParamForm(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void DeclVar(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void PartDeclVar(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void PartDeclSubRotina(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void CmdComposto(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void BLOCO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void ParamForm(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void DeclProcedure(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void LPARAM(node * BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);
void PROGRAM(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria);

//TIPO -> integer | boolean
void TIPO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
    node *token;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _INTEGER:
		    debugPrintSintat(BUFFER, "<tipo>");
	    	match(BUFFER, _INTEGER);
			break;
		case _BOOLEAN:
		    debugPrintSintat(BUFFER, "<tipo>");
	    	match(BUFFER, _BOOLEAN);
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <integer> ou <boolean>, porem foi encontrado <%s>\n", token->lcodigo,token->lexema);
			exit(1);
			break;
	}
}

//ID -> LETRA {LETRA | DIGITO}
void ID(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria, int buscar){
  node *token;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _LETTER:
		    if (buscar == 1){
		      if(buscarTabelaSimbolo(TSIMBOLO, token->lexema)==0)
                 printf("Variavel %s nao foi declarada no escopo. \n",token->lexema );
			  }else{
		      adicionaTabelaSimbolo(TSIMBOLO, token->lexema, escopo, tipo, categoria);
		    }
		    debugPrintSintat(BUFFER,"<id>");
			match(BUFFER, _LETTER);
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <id>, porem foi encontrado <%s>\n", token->lcodigo, token->lexema);
		    exit(1);
		    break;

	}
}

//NUMERO -> DIGITO {DIGITO}
void NUMERO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
  node *token;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _NUMBER:
          	if (strcmp(verifica_tipo, "integer ") != 0)
                printf("ERRO SEMANTICO linha %d: A variavel foi declarada com o tipo <%s> o valor atribuido e do tipo <%s>\n", token->lcodigo, verifica_tipo, "integer");
		    debugPrintSintat(BUFFER, "<numero>");
		    match(BUFFER, _NUMBER);
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <digito>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		    exit(1);
			break;
	}
}

//BOOL -> true | false
void BOOL(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _TRUE:
			if (strcmp(verifica_tipo, "boolean ") != 0)
                printf("ERRO SEMANTICO linha %d: A variavel foi declarada com o tipo <%s> o valor atribuido e do tipo <%s>\n", token->lcodigo, verifica_tipo, "boolean");
		    debugPrintSintat(BUFFER, "<bool>");
		    match(BUFFER, _TRUE);
			break;
		case _FALSE:
       	    if (strcmp(verifica_tipo, "boolean ") != 0)
                printf("ERRO SEMANTICO linha %d: A variavel foi declarada com o tipo <%s> o valor atribuido e do tipo <%s>\n", token->lcodigo, verifica_tipo, "boolean");
		     debugPrintSintat(BUFFER, "<bool>");
		    match(BUFFER, _FALSE);
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <true> ou <false>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		    exit(1);
			break;
	}
}

//VARIAVEL -> ID
void VARIAVEL(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	   debugPrintSintat(BUFFER, "<variavel>");
	   ID(BUFFER, TSIMBOLO, escopo, tipo, categoria, 1);
}

//FATOR -> VARIAVEL | NUMERO | BOOL | ( ExprSimples )
void FATOR(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _LETTER:
			debugPrintSintat(BUFFER, "<fator>");
			VARIAVEL(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			break;
		case _NUMBER:
		     debugPrintSintat(BUFFER, "<fator>");
			 NUMERO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			break;
		case _FALSE:
			 if (strcmp(verifica_tipo, token->tipo) != 0){
			 }
		   	 debugPrintSintat(BUFFER, "<fator>");
			 BOOL(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			break;
		case _TRUE:
			 debugPrintSintat(BUFFER, "<fator>");
			 BOOL(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			break;
		case _ABREP:
		     debugPrintSintat(BUFFER, "");
		     match(BUFFER, _ABREP);
			 ExprSimples(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			 if(lookahead(BUFFER) == _FECHAP){
			 	debugPrintSintat(BUFFER, "");
			 	match(BUFFER, _FECHAP);
	       	}else{
			    printf("ERRO SINTATICO na linha %d: Era esperado <)>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
				exit(1);
         	}
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <FATOR>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			break;
	}
}

//TERMO -> FATOR {(* | div) FATOR}
void TERMO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	while((lookahead(BUFFER)==_FALSE)||(lookahead(BUFFER)==_TRUE)||(lookahead(BUFFER) == _LETTER)||(lookahead(BUFFER) == _NUMBER)||(lookahead(BUFFER) == _OPMULT)||(lookahead(BUFFER) == _DIV)){
		switch(lookahead(BUFFER)){
			case _OPMULT:
			    debugPrintSintat(BUFFER, "<termo>");
			    match(BUFFER, _OPMULT);
				FATOR(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _DIV:
			    debugPrintSintat(BUFFER, "<termo>");
			    match(BUFFER, _DIV);
				FATOR(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _NUMBER:
				debugPrintSintat(BUFFER, "<termo>");
				FATOR(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _LETTER:
				debugPrintSintat(BUFFER, "<termo>");
				FATOR(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _TRUE:
				debugPrintSintat(BUFFER, "<termo>");
				FATOR(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _FALSE:
				debugPrintSintat(BUFFER, "<termo>");
				FATOR(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			default:
			    printf("ERRO SINTATICO na linha %d: Era esperado <*> ou <div>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
				break;
		}
	}
}
//ExprSimples -> [+ | -] TERMO {(+ | -) TERMO}
void ExprSimples(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	while((lookahead(BUFFER)==_FALSE)||(lookahead(BUFFER)==_TRUE)||(lookahead(BUFFER) == _LETTER)||(lookahead(BUFFER) == _NUMBER)||(lookahead(BUFFER) == _OPADI)||(lookahead(BUFFER) == _OPSUB)){
		switch(lookahead(BUFFER)){
			case _OPADI:
			    debugPrintSintat(BUFFER, "<expressao simples>");
			    match(BUFFER, _OPADI);
				TERMO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _OPSUB:
			    debugPrintSintat(BUFFER, "<expressao simples>");
		    	match(BUFFER, _OPSUB);
				TERMO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _NUMBER:
				debugPrintSintat(BUFFER, "<expressao simples>");
				TERMO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _LETTER:
				debugPrintSintat(BUFFER, "<expressao simples>");
				TERMO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _TRUE:
				debugPrintSintat(BUFFER, "<expressao simples>");
			    TERMO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			case _FALSE:
				debugPrintSintat(BUFFER, "<expressao simples>");
			    TERMO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				break;
			default:
			    printf("ERRO SINTATICO na linha %d: Era esperado <-> ou <+>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
				break;
		}
	}
}

//RELACAO -> = | <>| <| <= | >= | >
void RELACAO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _IGUAL:
			debugPrintSintat(BUFFER, "<relacao>");
			match(BUFFER, _IGUAL);
	    	break;
		case _MAIOR:
	    	debugPrintSintat(BUFFER, "<relacao>");
		    match(BUFFER, _MAIOR);
	    	break;
		case _MENOR:
			debugPrintSintat(BUFFER, "<relacao>");
			match(BUFFER, _MENOR);
	    	break;
		case _MAIORIGUAL:
			debugPrintSintat(BUFFER, "<relacao>");
			match(BUFFER, _MAIORIGUAL);
	    	break;
		case _ATRIBUICAO:
			debugPrintSintat(BUFFER, "<relacao>");
			match(BUFFER, _ATRIBUICAO);
	    	break;
		case _DIFERENTE:
			debugPrintSintat(BUFFER, "<relacao>");
	    	match(BUFFER, _DIFERENTE);
	    	break;
	    default:
			printf("ERRO SINTATICO na linha %d: Era esperado <RELACAO>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			break;
	}
}

//Expr -> ExprSimples [RELACAO ExprSimples]
void Expr(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	debugPrintSintat(BUFFER, "<expressao>");
	ExprSimples(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	while((lookahead(BUFFER) == _IGUAL)||(lookahead(BUFFER) == _MAIOR)||(lookahead(BUFFER) == _MENOR)||(lookahead(BUFFER) == _MAIORIGUAL)||(lookahead(BUFFER) == _ATRIBUICAO)||(lookahead(BUFFER) == _DIFERENTE)){
	    RELACAO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
    	ExprSimples(BUFFER, TSIMBOLO, escopo, tipo, categoria);
    }
}

//ListaID -> ID {, ID}
void ListaID(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	debugPrintSintat(BUFFER, "<lista de identificadores>");
	ID(BUFFER, TSIMBOLO, escopo, tipo, categoria,0);
    if (lookahead(BUFFER) == _VRGL) {
    	while(lookahead(BUFFER) == _VRGL) {
    		debugPrintSintat(BUFFER, "");
    		match(BUFFER, _VRGL);
			ID(BUFFER, TSIMBOLO, escopo, tipo, categoria, 0);
		}
    }
}
//SecParamForm -> [var] ListaID : TIPO
void SecParamForm(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	node *next;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _VAR:
			debugPrintSintat(BUFFER, "<seccao parametros formais>");
			match(BUFFER, _VAR);
			next = head(BUFFER);
			while((next->num != _INTEGER)&&(next->num != _BOOLEAN)){
				next = next->prox;
			}
			ListaID(BUFFER, TSIMBOLO, escopo, next->lexema, categoria);
			token = head(BUFFER);
	        if(lookahead(BUFFER) == _DSPNT){
	        	debugPrintSintat(BUFFER, "");
	        	match(BUFFER, _DSPNT);
				TIPO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	       	}else{
			    printf("ERRO SINTATICO na linha %d: Era esperado <:>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
				exit(1);
         	}
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <VAR>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			break;
	}
}

//DeclVar -> ListaID : TIPO
void DeclVar(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	node *next;
	next = head(BUFFER);
	int stop=1;
	while((next->num != _INTEGER)&&(next->num != _BOOLEAN)&&(stop = 1)){
		if((next->num == _INTEGER)&&(next->num == _BOOLEAN))
		   stop = 0;
		next = next->prox;
	}
	debugPrintSintat(BUFFER, "<declaracao variaveis>");
	ListaID(BUFFER, TSIMBOLO, escopo,  next->lexema, categoria);
	token = head(BUFFER);
	if(lookahead(BUFFER) == _DSPNT){
		debugPrintSintat(BUFFER, "");
	    match(BUFFER, _DSPNT);
		TIPO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	}else{
		printf("ERRO SINTATICO na linha %d: Era esperado <:>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		exit(1);
	}
}

//PartDeclVar -> var DeclVar {; DeclVar} ;
void PartDeclVar(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	categoria = "var";
	if(lookahead(BUFFER) == _VAR){
		while(lookahead(BUFFER) == _VAR){
			debugPrintSintat(BUFFER, "<parte de declaracoes de variaveis>");
			match(BUFFER, _VAR);
			DeclVar(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			token = head(BUFFER);
			if(lookahead(BUFFER) == _PNTVRGL){
				debugPrintSintat(BUFFER, "");
				match(BUFFER, _PNTVRGL);
		    }else{
			    printf("ERRO SINTATICO na linha %d: Era esperado <;>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
				exit(1);
	     	}
	    }
    }else{
        printf("Era esperado <VAR>, porem foi encontrado <%s>\n", token->lexema);
		exit(1);
	}
}

//PartDeclSubRotina -> {DeclProcedure;}
void PartDeclSubRotina(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	if(lookahead(BUFFER) == _PROCEDURE){
		DeclProcedure(BUFFER, TSIMBOLO, escopo, tipo, categoria);
		token = head(BUFFER);
		debugPrintSintat(BUFFER, "<parte de declaracoes de subrotinas>");
		if(lookahead(BUFFER) ==_PNTVRGL){
			debugPrintSintat(BUFFER, "");
			match(BUFFER, _PNTVRGL);
	    }else{
			printf("ERRO SINTATICO na linha %d: Era esperado1 <;>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			exit(1);
	    }
    }else{
		printf("ERRO SINTATICO na linha %d: Era esperado <procedure>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		exit(1);
	}
}

//CmdComposto -> begin CMD {; CMD} end
void CmdComposto(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
    node *token, *tabela;
	token = head(BUFFER);
	if (lookahead(BUFFER) == _BEGIN) {
		escopo++;
		debugPrintSintat(BUFFER,"<comando composto>");
		match(BUFFER, _BEGIN);
		CMD(BUFFER, TSIMBOLO, escopo, tipo, categoria);
		while((lookahead(BUFFER) == _PNTVRGL)&&(lookahead(BUFFER) != _END)){
		    	debugPrintSintat(BUFFER,"");
			  	match(BUFFER, _PNTVRGL);
				CMD(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	    }
	}else{
         printf("ERRO SINTATICO na linha %d: Era esperado <begin>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
	       exit(1);
    	}
	token = head(BUFFER);
    if (lookahead(BUFFER) == _END) {
    	tabela=topoTabelaSimbolo(TSIMBOLO);
    	while(tabela->escopo == escopo){
    		retirarTabelaSimbolo(TSIMBOLO);
         	tabela = topoTabelaSimbolo(TSIMBOLO);
        }
        escopo--;
		debugPrintSintat(BUFFER,"<comando composto>");
        match(BUFFER, _END);
    }else{
       printf("ERRO SINTATICO na linha %d: Era esperado <end>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
       exit(1);
	}
}

//BLOCO -> [PartDeclVar] [PartDeclSubRotina] CmdComposto
void BLOCO(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	debugPrintSintat(BUFFER,"<bloco>");
	while(lookahead(BUFFER) == _VAR){
	    PartDeclVar(BUFFER, TSIMBOLO, escopo, tipo, categoria);
    }
    while(lookahead(BUFFER) == _PROCEDURE){
	    PartDeclSubRotina(BUFFER, TSIMBOLO, escopo, tipo, categoria);
    }
	 CmdComposto(BUFFER, TSIMBOLO, escopo, tipo, categoria);
}

//ParamForm -> ( SecParamForm {; SecParamForm })
void ParamForm(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	debugPrintSintat(BUFFER,"<parametros formais>");
	switch(lookahead(BUFFER)){
		case _ABREP:
		    debugPrintSintat(BUFFER,"");
	    	match(BUFFER, _ABREP);
			SecParamForm(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			while(lookahead(BUFFER) == _PNTVRGL){
				debugPrintSintat(BUFFER,"");
				match(BUFFER, _PNTVRGL);
				SecParamForm(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			}
			token = head(BUFFER);
			if(lookahead(BUFFER) == _FECHAP){
			   debugPrintSintat(BUFFER,"");
			   match(BUFFER, _FECHAP);
	     	} else {
	     		printf("ERRO SINTATICO na linha %d: Era esperado <)>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		        exit(1);
			 }
	     	break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <(>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			break;
	}

}

//DeclProcedure -> procedure ID [PARAMFORM] ; BLOCO ;
void DeclProcedure(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _PROCEDURE:
		    escopo++;
		    categoria = "proc";
		    debugPrintSintat(BUFFER,"<declaracao de procedures>");
		    match(BUFFER, _PROCEDURE);
			ID(BUFFER, TSIMBOLO, escopo, tipo, categoria, 0);
			while(lookahead(BUFFER) == _ABREP){
			   ParamForm(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	     	}
	     	token = head(BUFFER);
			if(lookahead(BUFFER) == _PNTVRGL){
				debugPrintSintat(BUFFER,"");
				match(BUFFER, _PNTVRGL);
		    }else{
		       printf("ERRO SINTATICO na linha %d: Era esperado <;>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		       exit(1);
         	}
			BLOCO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <procedure>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		    break;
	}
}

//CMD -> ATRIB | CPROC | CmdComposto | COMDCOND1 | CMDREP1 | write ( ID )
void CMD(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	switch(lookahead(BUFFER)){
		case _WRITE:
				printf("\n\t*****Status da Tabela de Simbolo*****\n");
				exibeTabelaSimbolo(TSIMBOLO);
				debugPrintSintat(BUFFER,"<comando>");
				match(BUFFER, _WRITE);
				token = head(BUFFER);
	        	if(lookahead(BUFFER) == _ABREP){
	        		debugPrintSintat(BUFFER,"");
	        		match(BUFFER, _ABREP);
					ID(BUFFER, TSIMBOLO, escopo, tipo, categoria,1);
				}else{
					printf("ERRO SINTATICO na linha %d: Era esperado <(>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
					exit(1);
				}
				token = head(BUFFER);
	        	if(lookahead(BUFFER) == _FECHAP){
	        		debugPrintSintat(BUFFER,"");
	        		match(BUFFER, _FECHAP);
				}else{
					printf("ERRO SINTATICO na linha %d: Era esperado <)>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
					exit(1);
				}
			    break;
		case _LETTER:
				debugPrintSintat(BUFFER,"<comando>");
				if(lookahead(BUFFER) == _ABREP){
					CPROC(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				}else{
					ATRIB(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				}
			    break;
		case _BEGIN:
				escopo++;
				debugPrintSintat(BUFFER,"<comando>");
				CmdComposto(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			    break;
		case _IF:
				debugPrintSintat(BUFFER,"<comando>");
				COMDCOND1(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			    break;
		case _WHILE:
				debugPrintSintat(BUFFER,"<comando>");
				CMDREP1(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			    break;
	}
}

//ATRIB -> VARIAVEL := EXPR
void ATRIB(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	debugPrintSintat(BUFFER,"<atribuicao>");
	VARIAVEL(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	token = head(BUFFER);
	if(lookahead(BUFFER) == _ATRIBUICAO){
		debugPrintSintat(BUFFER,"<atribuicao>");
		match(BUFFER, _ATRIBUICAO);
		Expr(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	}else{
		printf("ERRO SINTATICO na linha %d: Era esperado <:=>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		exit(1);
	}
}

//CPROC -> ID [( LPARAM )]
void CPROC(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	debugPrintSintat(BUFFER,"<chamada de procedimento>");
	ID(BUFFER, TSIMBOLO, escopo, tipo, categoria,1);
    while(lookahead(BUFFER) == _ABREP){
    	debugPrintSintat(BUFFER,"");
    	match(BUFFER, _ABREP);
	    LPARAM(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	    token = head(BUFFER);
		if(lookahead(BUFFER) == _FECHAP){
			debugPrintSintat(BUFFER,"");
			match(BUFFER, _FECHAP);
		}else{
			printf("ERRO SINTATICO na linha %d: Era esperado <)>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			exit(1);
		}
    }
}
//LPARAM -> [( ID | NUMERO | BOOL ) {, ( ID | NUMERO | BOOL )}]
void LPARAM(node * BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria) {
	node *token;
	token = head(BUFFER);
    do{
	    if(lookahead(BUFFER) == _ABREP) {
	    	debugPrintSintat(BUFFER,"");
	    	match(BUFFER, _ABREP);
	        switch(lookahead(BUFFER)){
			      case _LETTER:
			      	debugPrintSintat(BUFFER,"<lista de parametros>");
			        ID(BUFFER, TSIMBOLO, escopo, tipo, categoria, 1);
			        break;
			      case _NUMBER:
			      	debugPrintSintat(BUFFER,"<lista de parametros>");
			        NUMERO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			        break;
			      case _FALSE:
			      	debugPrintSintat(BUFFER,"<lista de parametros>");
			        BOOL(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			        break;
			      case _TRUE:
			      	debugPrintSintat(BUFFER,"<lista de parametros>");
			        BOOL(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			        break;
			      default:
			        printf("ERRO SINTATICO na linha %d: Era esperado <id> ou <digito> ou <bool>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			        break;
	        }
		    if(lookahead(BUFFER) == _FECHAP){
		    	debugPrintSintat(BUFFER,"");
		        match(BUFFER, _FECHAP);
		    }else{
			   printf("ERRO SINTATICO na linha %d: Era esperado <)>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		       exit(1);
	    	}
	    }
    }while(lookahead(BUFFER) == _VRGL);
}

//COMDCOND1 -> if ( Expr ) then CMD {COMDCOND2}
void COMDCOND1(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	if(lookahead(BUFFER) == _IF){
		debugPrintSintat(BUFFER,"<comando condicional 1>");
		match(BUFFER, _IF);
		if(lookahead(BUFFER) == _ABREP){
			debugPrintSintat(BUFFER,"");
			match(BUFFER, _ABREP);
		    Expr(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			token = head(BUFFER);
		    if(lookahead(BUFFER) == _FECHAP){
		    	debugPrintSintat(BUFFER,"");
		    	match(BUFFER, _FECHAP);
		    }else{
		    	printf("ERRO SINTATICO na linha %d: Era esperado <)>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			    exit(1);
        	}
	    }
	    token = head(BUFFER);
		if(lookahead(BUFFER) == _THEN){
			debugPrintSintat(BUFFER,"<comando condicional 1>");
			match(BUFFER, _THEN);
		    CMD(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	    }else{
		    printf("ERRO SINTATICO na linha %d: Era esperado <then>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			exit(1);
        }
	    if(lookahead(BUFFER) == _ELSE){
	    	COMDCOND2(BUFFER, TSIMBOLO, escopo, tipo, categoria);
		}
	}else{
		printf("ERRO SINTATICO na linha %d: Era esperado <if>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		exit(1);
	}
}

//COMDCOND2 -> else CMD ----->>>> corre??o da gramatica
void COMDCOND2(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	if(lookahead(BUFFER) == _ELSE){
		debugPrintSintat(BUFFER,"<comando condicional 2>");
		match(BUFFER, _ELSE);
		CMD(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	}else{
		printf("ERRO SINTATICO na linha %d: Era esperado <else>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
		exit(1);
	}
}
//CMDREP1 -> while ( EXPR ) do CMD
void CMDREP1(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
	node *token;
	token = head(BUFFER);
	if(lookahead(BUFFER) == _WHILE){
		debugPrintSintat(BUFFER,"<comando repetitivo 1>");
		match(BUFFER, _WHILE);
		token = head(BUFFER);
		if(lookahead(BUFFER) == _ABREP){
			debugPrintSintat(BUFFER,"");
			match(BUFFER, _ABREP);
		    Expr(BUFFER, TSIMBOLO, escopo, tipo, categoria);
		    token = head(BUFFER);
		    if(lookahead(BUFFER) == _FECHAP){
		    	debugPrintSintat(BUFFER,"");
		    	match(BUFFER, _FECHAP);
		    }else{
		    	printf("ERRO SINTATICO na linha %d: Era esperado <)>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			    exit(1);
        	}
	    }else{
		    	printf("ERRO SINTATICO na linha %d: Era esperado <(>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			    exit(1);
        	}
        token = head(BUFFER);
		if(lookahead(BUFFER) == _DO){
			debugPrintSintat(BUFFER,"<comando repetitivo 1>");
			match(BUFFER, _DO);
		    CMD(BUFFER, TSIMBOLO, escopo, tipo, categoria);
	    }else{
		    printf("ERRO SINTATICO na linha %d: Era esperado <do>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			exit(1);
        }
	}else{
			printf("ERRO SINTATICO na linha %d: Era esperado <while>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			exit(1);
	}
}

//PROGRAM  -> ID ; BLOCO .
void PROGRAM(node *BUFFER, node *TSIMBOLO, int escopo, char* tipo, char* categoria){
    node *token;
    categoria ="prog";
    debugPrintSintat(BUFFER,"<program>");
	ID(BUFFER, TSIMBOLO, escopo, tipo, categoria, 0);
	token = head(BUFFER);
	switch(lookahead(BUFFER)){
		case _PNTVRGL:
			debugPrintSintat(BUFFER,"");
		    match(BUFFER, _PNTVRGL);
			BLOCO(BUFFER, TSIMBOLO, escopo, tipo, categoria);
			token = head(BUFFER);
			if (lookahead(BUFFER) == _PNT) {
				debugPrintSintat(BUFFER,"");
				match(BUFFER, _PNT);
			}else{
				printf("ERRO SINTATICO na linha %d: Era esperado <.>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			}
			break;
		default:
		    printf("ERRO SINTATICO na linha %d: Era esperado <;>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			break;
	}
}

void analisador_sintatico(node *BUFFER, int stop){
	node *token;
	token = head(BUFFER);
	node *TSIMBOLO=(node *)malloc(sizeof(node));
	int escopo = 0;
	char *tipo = "        ";
	char *categoria = "";
	iniciaTabelaSimbolo(TSIMBOLO);
	while(stop != -1){
		switch(lookahead(BUFFER)){
			case _PROGRAM:
				match(BUFFER, _PROGRAM);
				PROGRAM(BUFFER, TSIMBOLO, escopo, tipo, categoria);
				stop = 1;
				break;
			default:
			    printf("ERRO SINTATICO na linha %d: Era esperado <program>, porem foi encontrado <%s>\n",token->lcodigo, token->lexema);
			    stop = -1;
				break;
		}
		exibeTabelaSimbolo(TSIMBOLO);
	}
	printf("Analise sintatica finalizada.\n");
}

int main(){
	char str[80], linha[80], final[80] = "", url[]="", ch;
	int i = -1, r=1, lcodigo = 1, tamanho = 0, count=0, quantidade = 0;
	FILE *arq;
	FILE *saida;
	node *BUFFER=(node *)malloc(sizeof(node));
    inicia(BUFFER);
	//Definindo o arquivo a ser compilado como program.txt
	arq = fopen("program.txt", "r");
	//Arquivo de saida.txt exibe a lista de tokens lidos pelo automato do metodo leitor
	//a saida e exibida no formato <token,posicao>
	saida = fopen("saida.txt", "w");
	//Condicao que valida a leitura do arquivo program.txt caso nao seja possivel a leitura
	//a mensagem de erro sera exibido
	if(arq == NULL)
		printf("Erro, nao foi possivel abrir o arquivo\n");
	else{
		//O loop garante a leitura linha a linha do arquivo program.txt
		while((fgets(linha, 500, arq)!= NULL)&&(r!=0)){
		    //conta a quantidade de caracteres na linha que foi lida
			tamanho = strlen(linha);
			count=0;
			//identifica cada caracter das palavras lidas
			while(count<tamanho){
				ch=linha[count];
				if(ch == '\n') 
				lcodigo++;
				//condicao de parada para identificar o final de um token
			   	if(ch == ' ' || ch == '\n') {
			    	strcat(final, &ch);
			    	r = leitor(final, &i);
                  	if((r!=1)&&(r!=-1)){
			    	    insereBuffer(BUFFER, r, final, lcodigo);
				    	if (r!=0){
				    		fprintf(saida, "<%d,%s>\n", r, final);
				    	    quantidade++;
				    	}else{
				    		if(r==0){
				    		       printf("Erro Lexico: Entrada <%s> nao aceita!\n", final);
						           break;
						       }
						}
					}else{
						if(r==-1)
						    break;
					    }
			    	i = -1;
			    	strcpy(final, "");
			    	} else {
			    		strcat(final, &ch);
			    	}
			    count++;
			    }
		   }
		debugPrintLex(BUFFER);
		fclose(saida);
		fclose(arq);
		analisador_sintatico(BUFFER, quantidade);
		}
	libera(BUFFER);
    return 0;
}
